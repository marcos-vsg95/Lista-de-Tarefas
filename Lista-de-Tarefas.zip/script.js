document.addEventListener('DOMContentLoaded', function() {
    const taskInput = document.getElementById('new-task');
    const addTaskButton = document.getElementById('add-task');
    const taskList = document.getElementById('task-list');

    loadTasks();

    addTaskButton.addEventListener('click', function() {
        addTask(taskInput.value);
        taskInput.value = '';
    });

    taskList.addEventListener('click', function(event) {
        if (event.target.classList.contains('remove-task')) {
            removeTask(event.target.parentElement.getAttribute('data-id'));
        } else if (event.target.tagName === 'LI') {
            toggleTaskComplete(event.target.getAttribute('data-id'));
        }
    });

    function addTask(taskText) {
        if (taskText.trim() === '') {
            alert('Por favor, insira uma tarefa.');
            return;
        }
        const tasks = getTasksFromLocalStorage();
        const newTask = {
            id: Date.now().toString(),
            text: taskText,
            completed: false
        };
        tasks.push(newTask);
        saveTasksToLocalStorage(tasks);
        renderTasks();
    }

    function removeTask(taskId) {
        let tasks = getTasksFromLocalStorage();
        tasks = tasks.filter(task => task.id !== taskId);
        saveTasksToLocalStorage(tasks);
        renderTasks();
    }

    function toggleTaskComplete(taskId) {
        const tasks = getTasksFromLocalStorage();
        const task = tasks.find(task => task.id === taskId);
        if (task) {
            task.completed = !task.completed;
            saveTasksToLocalStorage(tasks);
            renderTasks();
        }
    }

    function getTasksFromLocalStorage() {
        return JSON.parse(localStorage.getItem('tasks')) || [];
    }

    function saveTasksToLocalStorage(tasks) {
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }

    function renderTasks() {
        const tasks = getTasksFromLocalStorage();
        taskList.innerHTML = '';
        tasks.forEach(task => {
            const li = document.createElement('li');
            li.textContent = task.text;
            li.setAttribute('data-id', task.id);
            if (task.completed) {
                li.classList.add('completed');
            }
            const removeButton = document.createElement('button');
            removeButton.textContent = 'Remover';
            removeButton.classList.add('remove-task');
            li.appendChild(removeButton);
            taskList.appendChild(li);
        });
    }

    function loadTasks() {
        renderTasks();
    }
});
